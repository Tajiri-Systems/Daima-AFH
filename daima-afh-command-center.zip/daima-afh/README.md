# Daima AFH Digital Command Center
### DSHS / WAC 388-76 Compliance Management System

---

## 🚀 STEP 1 — Deploy to Vercel (Your Live URL)

### Option A: Deploy via GitHub (Recommended)
1. Create a free account at https://github.com
2. Create a new repository named `daima-afh`
3. Upload all files from this folder into the repository
4. Go to https://vercel.com → Sign up with GitHub
5. Click "Add New Project" → Import your `daima-afh` repo
6. Click **Deploy** — your app goes live in ~2 minutes
7. Your URL will be: `daima-afh.vercel.app` (or similar)

### Option B: Deploy via Vercel CLI
```bash
npm install -g vercel
cd daima-afh
vercel
```
Follow the prompts. Done.

---

## 📊 STEP 2 — Connect Google Sheets (Permanent Data)

### 2a. Create your Spreadsheet
1. Go to https://sheets.google.com
2. Create a new spreadsheet
3. Name it: **Daima AFH Command Center**
4. Create 4 tabs with these exact names:
   - `Residents`
   - `Staff`
   - `Incidents`
   - `Checklist`
5. Copy your **Spreadsheet ID** from the URL:
   `https://docs.google.com/spreadsheets/d/YOUR_ID_IS_HERE/edit`

### 2b. Set Up the Backend Script
1. In your spreadsheet: **Extensions → Apps Script**
2. Delete any existing code
3. Open `APPS_SCRIPT.gs` from this package
4. Paste the entire contents into the Apps Script editor
5. Replace `PASTE_YOUR_SPREADSHEET_ID_HERE` with your actual Spreadsheet ID
6. Click **Save** (💾)

### 2c. Deploy as Web App
1. Click **Deploy → New Deployment**
2. Click the gear icon → Select type: **Web app**
3. Settings:
   - Description: `Daima AFH API`
   - Execute as: **Me**
   - Who has access: **Anyone**
4. Click **Deploy**
5. Authorize the permissions when prompted
6. **Copy the Web App URL** (looks like: `https://script.google.com/macros/s/ABC.../exec`)

### 2d. Add Variables to Vercel
1. Go to https://vercel.com → Your project → **Settings → Environment Variables**
2. Add these two variables:

| Name | Value |
|------|-------|
| `REACT_APP_SHEET_API_URL` | Your Web App URL from step 2c |
| `REACT_APP_SPREADSHEET_ID` | Your Spreadsheet ID from step 2a |

3. Go to **Deployments → Redeploy** (select "Redeploy with existing build cache")
4. Refresh your app — the indicator in the top bar will turn **green: ● Sheets Live**

---

## ✏️ STEP 3 — Add Your Real Data

Once connected to Google Sheets, open your spreadsheet and add your real:
- **Residents** tab: id, name, room, admission, level, physician, chartComplete, flags
- **Staff** tab: id, name, role, hired, cpr, hca, food, dementia
- **Incidents** tab: will auto-populate as you log incidents in the app

Or simply edit the default data arrays in `src/App.jsx` before deploying.

---

## 🔒 Security Note
The Google Apps Script is deployed as "Anyone can access" which means anyone
with the URL can read/write your spreadsheet. For a more secure setup, restrict
access and use OAuth — reach out for help setting that up.

---

## 📞 Support
Built specifically for Daima AFH — Washington State WAC 388-76 compliant.
