// ─────────────────────────────────────────────────────────────
//  DAIMA AFH — Google Sheets Integration
//  
//  SETUP INSTRUCTIONS:
//  1. Go to https://sheets.google.com and create a new spreadsheet
//  2. Name it: "Daima AFH Command Center"
//  3. Create these tabs (exact names): Residents, Staff, Incidents, Checklist
//  4. Go to https://script.google.com → New Project
//  5. Paste the Apps Script code from APPS_SCRIPT.gs into the editor
//  6. Click Deploy → New Deployment → Web App
//     - Execute as: Me
//     - Who has access: Anyone
//  7. Copy the deployment URL and paste it below as SHEET_API_URL
//  8. Copy your Spreadsheet ID from the URL bar and paste below
// ─────────────────────────────────────────────────────────────

export const SHEETS_CONFIG = {
  // Paste your Google Apps Script Web App URL here after deployment:
  SHEET_API_URL: process.env.REACT_APP_SHEET_API_URL || "",

  // Your Google Spreadsheet ID (from the URL: /spreadsheets/d/YOUR_ID_HERE/edit)
  SPREADSHEET_ID: process.env.REACT_APP_SPREADSHEET_ID || "",

  // Sheet tab names (must match exactly)
  TABS: {
    RESIDENTS: "Residents",
    STAFF:     "Staff",
    INCIDENTS: "Incidents",
    CHECKLIST: "Checklist",
  }
};

// ─────────────────────────────────────────────────────────────
//  API HELPER — read/write rows to Google Sheets
// ─────────────────────────────────────────────────────────────

export async function sheetsRead(tab) {
  if (!SHEETS_CONFIG.SHEET_API_URL) return null;
  try {
    const url = `${SHEETS_CONFIG.SHEET_API_URL}?action=read&tab=${tab}`;
    const res = await fetch(url);
    const data = await res.json();
    return data.rows || null;
  } catch (e) {
    console.warn("Sheets read failed:", e);
    return null;
  }
}

export async function sheetsWrite(tab, rows) {
  if (!SHEETS_CONFIG.SHEET_API_URL) return false;
  try {
    const res = await fetch(SHEETS_CONFIG.SHEET_API_URL, {
      method: "POST",
      body: JSON.stringify({ action: "write", tab, rows }),
    });
    const data = await res.json();
    return data.success || false;
  } catch (e) {
    console.warn("Sheets write failed:", e);
    return false;
  }
}

export async function sheetsAppend(tab, row) {
  if (!SHEETS_CONFIG.SHEET_API_URL) return false;
  try {
    const res = await fetch(SHEETS_CONFIG.SHEET_API_URL, {
      method: "POST",
      body: JSON.stringify({ action: "append", tab, row }),
    });
    const data = await res.json();
    return data.success || false;
  } catch (e) {
    console.warn("Sheets append failed:", e);
    return false;
  }
}
