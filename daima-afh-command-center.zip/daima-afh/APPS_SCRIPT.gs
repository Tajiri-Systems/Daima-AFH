// ═══════════════════════════════════════════════════════════════
//  DAIMA AFH — Google Apps Script Backend
//  
//  PASTE THIS ENTIRE FILE into https://script.google.com
//  Then: Deploy → New Deployment → Web App
//        Execute as: Me | Who has access: Anyone
//  Copy the Web App URL into your .env file.
// ═══════════════════════════════════════════════════════════════

const SPREADSHEET_ID = "PASTE_YOUR_SPREADSHEET_ID_HERE";

function doGet(e) {
  const action = e.parameter.action;
  const tab    = e.parameter.tab;

  if (action === "read") {
    return readSheet(tab);
  }
  return ContentService
    .createTextOutput(JSON.stringify({ error: "Unknown action" }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const body   = JSON.parse(e.postData.contents);
  const action = body.action;
  const tab    = body.tab;

  if (action === "write")  return writeSheet(tab, body.rows);
  if (action === "append") return appendRow(tab, body.row);

  return ContentService
    .createTextOutput(JSON.stringify({ error: "Unknown action" }))
    .setMimeType(ContentService.MimeType.JSON);
}

// ── READ all rows from a tab (returns array of objects) ────────
function readSheet(tabName) {
  try {
    const ss    = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheet = ss.getSheetByName(tabName);
    if (!sheet) return jsonResponse({ rows: [] });

    const data    = sheet.getDataRange().getValues();
    if (data.length < 2) return jsonResponse({ rows: [] });

    const headers = data[0];
    const rows    = data.slice(1).map(row => {
      const obj = {};
      headers.forEach((h, i) => { obj[h] = row[i]; });
      return obj;
    });
    return jsonResponse({ rows });
  } catch (err) {
    return jsonResponse({ error: err.toString(), rows: [] });
  }
}

// ── WRITE (replace all data rows) ─────────────────────────────
function writeSheet(tabName, rows) {
  try {
    const ss    = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet   = ss.getSheetByName(tabName);
    if (!sheet) sheet = ss.insertSheet(tabName);

    if (!rows || rows.length === 0) return jsonResponse({ success: true });

    const headers = Object.keys(rows[0]);
    const values  = [headers, ...rows.map(r => headers.map(h => r[h] ?? ""))];

    sheet.clearContents();
    sheet.getRange(1, 1, values.length, headers.length).setValues(values);

    // Style the header row
    sheet.getRange(1, 1, 1, headers.length)
      .setBackground("#0d1117")
      .setFontColor("#f6a623")
      .setFontWeight("bold");

    return jsonResponse({ success: true });
  } catch (err) {
    return jsonResponse({ success: false, error: err.toString() });
  }
}

// ── APPEND a single row ────────────────────────────────────────
function appendRow(tabName, row) {
  try {
    const ss    = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet   = ss.getSheetByName(tabName);
    if (!sheet) {
      sheet = ss.insertSheet(tabName);
      const headers = Object.keys(row);
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      sheet.getRange(1, 1, 1, headers.length)
        .setBackground("#0d1117")
        .setFontColor("#f6a623")
        .setFontWeight("bold");
    }

    const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    const newRow  = headers.map(h => row[h] ?? "");
    sheet.appendRow(newRow);

    return jsonResponse({ success: true });
  } catch (err) {
    return jsonResponse({ success: false, error: err.toString() });
  }
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
